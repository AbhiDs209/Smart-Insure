import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { User, Heart, Shield, TrendingUp, Star } from "lucide-react";

const Recommendations = () => {
  const [profile, setProfile] = useState({
    age: "",
    income: "",
    dependents: "",
    riskProfile: "",
    existingPolicies: ""
  });

  
  const [loading, setLoading] = useState(false);
  const [recs, setRecs] = useState<any[]>([]);
  const [error, setError] = useState(\"\");
const [showRecommendations, setShowRecommendations] = useState(false);

  const recommendations = [];


const handleGetRecommendations = async () => {
  setLoading(true);
  setError(""); setRecs([]);
  try {
    const age = Number(profile.age) || 30;
    const annual_budget = Number(profile.income) || 15000;
    let dependents_count = 0;
    if (profile.dependents === '1-2') dependents_count = 1;
    else if (profile.dependents === '3-4') dependents_count = 3;
    else if (profile.dependents === '5+') dependents_count = 5;
    else dependents_count = Number(profile.dependents) || 0;

    const payload = {
      age,
      gender: profile.gender || 'male',
      annual_budget,
      marital_status: profile.marital || 'single',
      dependents_count,
      preexisting_conditions: (profile.preexisting || '').split(',').map(s=>s.trim()).filter(Boolean),
      preferred_hospitals: (profile.preferred_hospitals || '').split(',').map(s=>s.trim()).filter(Boolean),
      location: profile.location || 'Delhi',
      wants_maternity: !!profile.wants_maternity,
      policy_type_preference: profile.policy_type || 'any'
    };

    const res = await fetch(RECO_API, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    if (!res.ok) {
      const text = await res.text();
      throw new Error('API error ' + res.status + ': ' + text);
    }
    const data = await res.json();
    setRecs(data.recommendations || []);
    setShowRecommendations(true);
    setNote(data.note || '');
  } catch (err:any) {
    console.error(err);
    setError(err.message || 'Failed to get recommendations from API');
  } finally {
    setLoading(false);
  }
};



      const res = await fetch(\"http://localhost:8000/recommend\", {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      if (!res.ok) {
        throw new Error('API error ' + res.status);
      }
      const data = await res.json();
      setRecs(data.recommendations || []);
      setShowRecommendations(true);
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'Failed to get recommendations');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-subtle py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-foreground mb-4">
            Personalized Insurance Recommendations
          </h1>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Get AI-powered insurance recommendations tailored to your unique profile, 
            needs, and financial goals.
          </p>
        </div>

        {/* Profile Form */}
        <div className="insurance-card p-8 mb-8">
          <div className="flex items-center gap-3 mb-6">
            <User className="h-6 w-6 text-primary" />
            <h2 className="text-2xl font-semibold">Tell Us About Yourself</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">
                Age
              </label>
              <Input
                type="number"
                placeholder="Enter your age"
                value={profile.age}
                onChange={(e) => setProfile({...profile, age: e.target.value})}
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-foreground mb-2">
                Annual Income (₹)
              </label>
              <Input
                type="number"
                placeholder="e.g., 800000"
                value={profile.income}
                onChange={(e) => setProfile({...profile, income: e.target.value})}
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-foreground mb-2">
                Number of Dependents
              </label>
              <Select value={profile.dependents} onValueChange={(value) => 
                setProfile({...profile, dependents: value})
              }>
                <SelectTrigger>
                  <SelectValue placeholder="Select dependents" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="0">No dependents</SelectItem>
                  <SelectItem value="1-2">1-2 dependents</SelectItem>
                  <SelectItem value="3-4">3-4 dependents</SelectItem>
                  <SelectItem value="5+">5+ dependents</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="block text-sm font-medium text-foreground mb-2">
                Risk Profile
              </label>
              <Select value={profile.riskProfile} onValueChange={(value) => 
                setProfile({...profile, riskProfile: value})
              }>
                <SelectTrigger>
                  <SelectValue placeholder="Select risk profile" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="conservative">Conservative</SelectItem>
                  <SelectItem value="moderate">Moderate</SelectItem>
                  <SelectItem value="aggressive">Aggressive</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-foreground mb-2">
                Existing Insurance Policies
              </label>
              <Input
                placeholder="e.g., Term life ₹10L, Health ₹5L"
                value={profile.existingPolicies}
                onChange={(e) => setProfile({...profile, existingPolicies: e.target.value})}
              />
            </div>
          </div>

          <div className="mt-8 text-center">
            <Button 
              onClick={handleGetRecommendations}
              className="hero-button px-8 py-3"
            >
              Get My Recommendations
            </Button>
          </div>
        </div>

        {/* Recommendations */}
        {showRecommendations && (
          <div className="space-y-6">
            <h2 className="text-2xl font-semibold text-center mb-6">
              Your Personalized Recommendations
            </h2>

            {((recs.length?recs:recommendations).map((rec) => (
              <Card key={rec.id} className="insurance-card">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-primary/10 rounded-lg text-primary">
                        {rec.icon}
                      </div>
                      <div>
                        <CardTitle className="text-lg">{rec.type}</CardTitle>
                        <p className="text-sm text-muted-foreground">{rec.policy}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="flex items-center gap-1 mb-1">
                        <Star className="h-4 w-4 text-yellow-500" />
                        <span className="font-semibold text-primary">{rec.match}% Match</span>
                      </div>
                      <Badge variant="secondary">Recommended</Badge>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-4 mb-4">
                    <div>
                      <p className="text-sm text-muted-foreground">Coverage</p>
                      <p className="font-semibold text-lg">{rec.coverage}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Premium</p>
                      <p className="font-semibold text-lg text-primary">{rec.premium}</p>
                    </div>
                  </div>

                  <p className="text-sm text-muted-foreground mb-3">{rec.reason}</p>

                  <div className="flex flex-wrap gap-2 mb-4">
                    {rec.features.map((feature) => (
                      <Badge key={feature} variant="outline" className="text-xs">
                        {feature}
                      </Badge>
                    ))}
                  </div>

                  <div className="flex gap-2">
                    <Button className="hero-button flex-1">
                      View Details
                    </Button>
                    <Button variant="outline" className="flex-1">
                      Compare Similar
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}

            <div className="text-center mt-8">
              <p className="text-sm text-muted-foreground">
                💡 AI-powered recommendations will be enhanced once backend integration is complete.
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Recommendations;